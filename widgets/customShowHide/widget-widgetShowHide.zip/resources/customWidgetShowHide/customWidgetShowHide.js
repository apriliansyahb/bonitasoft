(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customWidgetShowHide', function() {
    return {
      controllerAs: 'ctrl',
      controller: /**
 * The controller is a JavaScript function that augments the AngularJS scope and exposes functions that can be used in the custom widget template
 * 
 * Custom widget properties defined on the right can be used as variables in a controller with $scope.properties
 * To use AngularJS standard services, you must declare them in the main function arguments.
 * 
 * You can leave the controller empty if you do not need it.
 */
function ($scope) {
    $scope.isExpand = true;
    
    // The DOM element to hide
    var $elem = null; 
    
    
    $scope.toggle = function() {
        var $elem = jQuery($scope.properties.elementSelector);
        $elem.slideToggle("slow");
        $scope.isExpand = $scope.isExpand === false ? true: false;
    };
},
      template: '<div class="text-{{ properties.alignment }}">\n    \n    <!-- look and feel = image -->\n    <span \n        style="display: inline-block; padding: 0px;"  \n        class="btn" \n        ng-click="toggle()" \n        ng-hide="\'image\'!==properties.lookAndFeel" \n    >\n        <img src="widgets/customWidgetShowHide/assets/img/widgetShowHide_icon_plus.png" ng-hide="isExpand" class="ng-hide"  />\n        <img src="widgets/customWidgetShowHide/assets/img/widgetShowHide_icon_minus.png" ng-hide="!isExpand" class="ng-hide"  />\n    </span>\n    \n     <!-- look and feel = button -->\n    <button \n        ng-click="toggle()"\n        class="btn btn-{{ properties.buttonStyle }}" \n        ng-hide="\'button\'!==properties.lookAndFeel"\n    >\n        <i class="glyphicon glyphicon-plus" ng-hide="isExpand"></i>\n        <i class="glyphicon glyphicon-minus" ng-hide="!isExpand"></i>\n    </button>\n</div>\n'
    };
  });
