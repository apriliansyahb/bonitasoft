(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customWidgetTextArea', function() {
    return {
      controllerAs: 'ctrl',
      controller: /**
 * The controller is a JavaScript function that augments the AngularJS scope and exposes functions that can be used in the custom widget template
 * 
 * Custom widget properties defined on the right can be used as variables in a controller with $scope.properties
 * To use AngularJS standard services, you must declare them in the main function arguments.
 * 
 * You can leave the controller empty if you do not need it.
 */
function ($scope, $log, widgetNameFactory) {

    'use strict';
    this.name = widgetNameFactory.getName('customWidgetTextArea');
    
   
    if (!$scope.properties.isBound('value')) {
        $log.error('the pbTextArea property named "value" need to be bound to a variable');
    }

},
      template: '<div ng-class="{ \'form-horizontal\': properties.labelPosition === \'left\' && !properties.labelHidden, \'row\': properties.labelPosition === \'top\' && !properties.labelHidden || properties.labelHidden }">\n   <div class="form-group">\n      <label \n        ng-if="!properties.labelHidden" \n        ng-class="{ \'control-label--required\': properties.required }" \n        class="control-label col-xs-{{ !properties.labelHidden && properties.labelPosition === \'left\' ? properties.labelWidth : 12 }}">\n          \n            {{ properties.label | uiTranslate }}\n            \n             <a href="#0"\n                data-toggle="tooltip" \n                tooltip-placement="{{ properties.tooltipDirection }}"\n                tooltip="{{ properties.tooltipMessage }}"\n                tooltip-class="{{ properties.tooltipClass }}"\n                ng-class="btn"\n                style="float:right; text-decoration: none;"\n                ng-if="properties.displayTooltip"\n            >\n              <i class="glyphicon glyphicon-{{ properties.tooltipIcon }}"></i>\n            </a>  \n      </label>    \n       \n      <div class="col-xs-{{ 12 - (!properties.labelHidden && properties.labelPosition === \'left\' ? properties.labelWidth : 0) }}">\n         <textarea \n            class="form-control" \n            name="{{ctrl.name}}"\n            ng-model="properties.value"\n            ng-required="properties.required"\n            ng-minlength="properties.minLength"\n            ng-maxlength="properties.maxLength"\n            ng-readonly="properties.readOnly"\n            ng-attr-placeholder="{{ properties.placeholder }}"\n            ng-style="{{ properties.customStyle }}"\n            ></textarea>\n         <div ng-messages="$form[ctrl.name].$dirty && $form[ctrl.name].$error" ng-messages-include="forms-generic-errors.html" role="alert"></div>\n      </div>\n   </div>\n</div>'
    };
  });
