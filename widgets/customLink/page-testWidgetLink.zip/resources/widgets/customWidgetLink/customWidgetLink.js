(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customWidgetLink', function() {
    return {
      template: '<div class="text-{{ properties.alignment }}">\n    <a \n        ng-class="properties.buttonStyle !== \'none\' ? \'btn btn-\' + properties.buttonStyle : \'\'" \n        ng-href="{{ properties.targetUrl }}" \n        target="{{ properties.target }}" \n        ng-style="{{ properties.customStyle }}"\n        >\n        <i class="glyphicon glyphicon-{{ properties.iconClass }}" ng-if="properties.displayIcon"></i> {{ properties.text | uiTranslate }}\n    </a>\n</div>'
    };
  });
